
*******************
Aturan Pakai
*******************
1. download zip terus ekstrak zip nya
2. rename pustaka-booking-master menjadi pustaka booking
3. pindahkan ke dalam htdocs
4. buka phpmyadmin buat database dengan nama pustaka
5. pilih import,kemudian cari ke dalam folder pustaka-booking tadi ada folder database kemudian pilih pustaka.sql
