<section>
	<h1><?php echo $judul ?></h1>
	<h4>Nama</h4>
	<ul type="disc">
		<li>Nama Depan : Imam</li>
		<li>Nama Belakang : Nawawi</li>
	</ul>
	<br>
	<h4>Alamat</h4>
	<ul type="none">
		<li> Jalan Ciledug Raya No. 168 Pesanggrahan</li>
	</ul>
	
	<h4>Tempat Lahir</h4>
	<ul type="none">
		<li>Cirebon</li>
	</ul>

	<h4>Olah Raga Favorit</h4>
	<ul type="square">
		<li>Bulutangkis</li>
		<li>Catur</li>
	</ul>
	

</section>